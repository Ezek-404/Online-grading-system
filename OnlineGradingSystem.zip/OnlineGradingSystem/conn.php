<?php
$con = mysqli_connect("localhost","root","","db");

if(!$con)
{
  die("connection error!");
}
?>